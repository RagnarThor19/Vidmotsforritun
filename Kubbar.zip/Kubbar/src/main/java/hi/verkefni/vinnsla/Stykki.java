package hi.verkefni.vinnsla;

public class Stykki {
    private final int tala;

    public Stykki(int tala) {
        this.tala = tala;
    }

    public int getTala() {
        return tala;
    }
}
